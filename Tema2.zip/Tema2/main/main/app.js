/**
 * the function renders an object to a tagged string and performs token substitution
 * @param {object} input - a javascript object representing a hierachycal structure  
 * @param {object} values - a list of key value pairs where the key is a token to be replaced with the value in strings present in input
 */

function render(input, values){
    //cerinta 1
    if(JSON.stringify(input) === '{}') return '';

    //cerinta 2
    if (typeof input != 'object'){
		throw new Error('InvalidType');
	}

    var rezultat = '';
    var contorVal = -1; //tinem cont de urmatoarea valoare din values
    var value; //string-ul cautat in input care urmeaza a fi inlocuit ex: ${v1}

    if(JSON.stringify(values) === '{}'){
        recursiv(input);
        return rezultat;
    }
    else{
        contorVal = 0;
        value = '${' + Object.keys(values)[contorVal] + '}';
        recursiv(input);
        return rezultat;
    }

    function recursiv(obj){
        //retinem cheile si valorile obiectului curent
        let cheiObiect = Object.keys(obj);
        let valoriObiect = Object.values(obj);

        for(let i=0; i<cheiObiect.length; i++){
            //verificam daca exista obiecte imbricate
            if(typeof valoriObiect[i] == 'object'){
                rezultat += '<' + cheiObiect[i] + '>';
                recursiv(valoriObiect[i]);
                rezultat += '</' + cheiObiect[i] + '>';
            }
            else{
                rezultat += '<' + cheiObiect[i] + '>';
                //verificam daca exista campuri in obiectul values (daca da contorVal este 0)
                if(contorVal != -1){
                    //verificam daca in valoarea curenta din input exista un token de inlocuit
                    if(valoriObiect[i].indexOf(value) != -1){
                        rezultat += valoriObiect[i].replace(value, Object.values(values)[contorVal]);
                        contorVal++;
                        //daca mai exista valori in obiectul values, acesta este retinut in value pt a fi cautat intr-o iteratie viitoare
                        if(contorVal<Object.keys(values).length){
                            value = '${' + Object.keys(values)[contorVal] + '}';
                        }
                    }
                    else rezultat += valoriObiect[i];
                }
                else rezultat += valoriObiect[i];
                rezultat += '</' + cheiObiect[i] + '>';
            }
        }
    }
}

module.exports = {
    render
}